// ---------- Footer year ----------
document.getElementById("year").textContent = new Date().getFullYear();

// ---------- Mobile menu ----------
const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("nav");

menuBtn.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", open);
});
nav.addEventListener("click", (e) => {
  if (e.target.tagName === "A") {
    nav.classList.remove("open");
    menuBtn.setAttribute("aria-expanded", "false");
  }
});

// ---------- Light / dark theme ----------
const root = document.documentElement;
const themeBtn = document.getElementById("themeBtn");

function applyTheme(theme) {
  root.setAttribute("data-theme", theme);
  themeBtn.textContent = theme === "dark" ? "Light mode" : "Dark mode";
}

let saved = null;
try { saved = localStorage.getItem("theme"); } catch (e) {}
const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
applyTheme(saved || (prefersDark ? "dark" : "light"));

themeBtn.addEventListener("click", () => {
  const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
  applyTheme(next);
  try { localStorage.setItem("theme", next); } catch (e) {}
});

// ---------- Project filter ----------
const chips = document.querySelectorAll(".chip");
const projects = document.querySelectorAll(".project");

chips.forEach((chip) => {
  chip.addEventListener("click", () => {
    chips.forEach((c) => c.classList.remove("active"));
    chip.classList.add("active");
    const filter = chip.dataset.filter;
    projects.forEach((p) => {
      p.hidden = !(filter === "all" || p.dataset.type === filter);
    });
  });
});

// ---------- Contact form ----------
const form = document.getElementById("contactForm");
const statusEl = document.getElementById("formStatus");

function setError(field, message) {
  const el = form.querySelector(`.error[data-for="${field.id}"]`);
  el.textContent = message;
  field.setAttribute("aria-invalid", message ? "true" : "false");
}

function validate() {
  let valid = true;
  const name = form.name;
  const email = form.email;
  const message = form.message;

  if (name.value.trim().length < 2) { setError(name, "Enter your name."); valid = false; }
  else setError(name, "");

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
    setError(email, "Enter a valid email address."); valid = false;
  } else setError(email, "");

  if (message.value.trim().length < 10) {
    setError(message, "Write at least 10 characters."); valid = false;
  } else setError(message, "");

  return valid;
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  statusEl.textContent = "";
  if (!validate()) return;

  // Opens the visitor's email app with the message filled in.
  // To send without an email app, connect a service such as Formspree or EmailJS.
  const subject = encodeURIComponent("Portfolio message from " + form.name.value.trim());
  const body = encodeURIComponent(form.message.value.trim() + "\n\n" + form.name.value.trim() + "\n" + form.email.value.trim());
  window.location.href = `mailto:you@example.com?subject=${subject}&body=${body}`;

  statusEl.textContent = "Your email app should open with the message ready to send.";
  form.reset();
});
